# Account Switcher

Multi-site, multi-account switcher app — ChatGPT, Claude, Google Flow, ya koi bhi
website k multiple email logins ko ek button tap se switch karne k liye.

## Sabse Simple Tareeqa (Android Studio Ki Zaroorat Nahi)

1. github.com pe free account banayein (agar nahi hai).
2. Naya **repository** banayein (naam kuch bhi, e.g. `account-switcher`).
3. Is poori `MultiAccountSwitcher` folder ka sara content us repo me upload
   kar dein (GitHub website pe "Add file → Upload files" se drag-drop kar
   sakte hain, ya `git push` se agar git pata hai).
4. Repo k **Actions** tab me jayein — "Build APK" workflow khud chal jayega
   (ya "Run workflow" button se manually chalayein).
5. Build complete (2-3 min) hone k baad us run k neeche **Artifacts** section
   me `app-debug-apk` milega — download karein (zip me APK hoga).
6. APK ko phone pe copy kar k install karein (Settings → "Install unknown
   apps" ko us file manager/browser k liye allow karna paray ga).

Bas — koi software install nahi karna, sirf browser se APK mil jayega.

## Android Studio Wala Tareeqa (Agar Khud Edit/Debug Karna Ho)

1. Android Studio khol kar **Open** → is folder (`MultiAccountSwitcher`) ko select karein.
2. Gradle sync hone dein (pehli baar internet chahiye, dependencies download hongi).
3. `app` module ko kisi emulator ya real phone (USB debugging on) pe **Run** karein.

## Kaise Use Karein

1. **+ button** (bottom-right) se site add karein — naam aur URL (e.g. "ChatGPT",
   `https://chatgpt.com`).
2. Site card k neeche **"+ Add Account"** dabayein — email/label likhein (e.g.
   `tahir@gmail.com`) → "Continue" dabate hi browser (WebView) khulega.
3. Us browser k andar site pe **normal tareeqay se login karein** (email/password,
   Google sign-in, jo bhi site maangay).
4. Login mukammal hone k baad neeche **"Save Session"** button dabayein — is se
   session cookies securely save ho jayengi.
5. Wapis Main Screen pe har account ka **apna button (chip)** nazar aayega. Jis
   account pe jana ho uska button dabayein — turant pehla session background me
   chala jayega aur wahi account load ho jayega (dobara login ki zaroorat nahi).
6. **Recent** card sabse upar hamesha last-used account dikhata hai — ek tap se
   wapis wahan pahunch sakte hain.

## Kaam Kaisay Karta Hai (Technical)

- Har account k login session (cookies) `EncryptedSharedPreferences` me
  securely save hote hain — plain text me kahin nahi.
- Account switch karte waqt app us site k current cookies clear kar k, save
  ki hui cookies wapis inject kar deti hai (`CookieSessionManager.kt`) — is
  se real logout/login API calls ki zaroorat nahi parti, sirf session swap
  hota hai, jo tez aur reliable hai.
- Chip (button) ka amber color = session saved / ready. Gray = account add
  hua hai lekin abhi login nahi hua.
- Chip pe (x) icon se account delete kar sakte hain, site card k top-right
  delete icon se pura site remove kar sakte hain.

## Zaroori Note

- Kuch sites (banking, kuch enterprise tools) device-fingerprinting ya
  strict session policies use karti hain jahan cookie-swap kaam nahi karega
  — lekin ChatGPT, Claude, aur zyada tar general web apps k liye ye
  approach reliably chalta hai.
- Agar kisi site ne cookies ko HttpOnly + very short expiry diya ho to
  session jaldi expire ho sakta hai — us surat me sirf dobara login + Save
  Session karna hoga.
