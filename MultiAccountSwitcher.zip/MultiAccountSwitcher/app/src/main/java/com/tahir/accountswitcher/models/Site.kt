package com.tahir.accountswitcher.models

/**
 * Represents a website (e.g. ChatGPT, Claude, Google Flow) that has
 * one or more accounts (emails) the user switches between.
 */
data class Site(
    val id: String,
    var name: String,       // e.g. "ChatGPT"
    var url: String,        // e.g. "https://chatgpt.com"
    val accounts: MutableList<Account> = mutableListOf()
)
