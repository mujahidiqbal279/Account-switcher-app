package com.tahir.accountswitcher

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import com.tahir.accountswitcher.adapters.SiteAdapter
import com.tahir.accountswitcher.data.StorageManager
import com.tahir.accountswitcher.databinding.ActivityMainBinding
import com.tahir.accountswitcher.databinding.DialogAddAccountBinding
import com.tahir.accountswitcher.databinding.DialogAddSiteBinding
import com.tahir.accountswitcher.models.Account
import com.tahir.accountswitcher.models.Site

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var storage: StorageManager
    private lateinit var adapter: SiteAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        storage = StorageManager(this)

        val sites = storage.getSites()
        adapter = SiteAdapter(
            sites = sites,
            onAccountClick = { site, account -> openAccount(site, account) },
            onAddAccountClick = { site -> showAddAccountDialog(site) },
            onDeleteSite = { site -> confirmDeleteSite(site) },
            onDeleteAccount = { site, account -> confirmDeleteAccount(site, account) }
        )
        binding.sitesRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.sitesRecyclerView.adapter = adapter

        binding.addSiteFab.setOnClickListener { showAddSiteDialog() }

        refreshEmptyState()
        refreshRecent()
    }

    override fun onResume() {
        super.onResume()
        // Sites/accounts list may have changed (e.g. cookies saved) while WebViewActivity was open
        reloadSites()
        refreshRecent()
    }

    private fun reloadSites() {
        val fresh = storage.getSites()
        adapter.let {
            // Simplest correct approach: rebuild adapter with fresh data
            binding.sitesRecyclerView.adapter = SiteAdapter(
                sites = fresh,
                onAccountClick = { site, account -> openAccount(site, account) },
                onAddAccountClick = { site -> showAddAccountDialog(site) },
                onDeleteSite = { site -> confirmDeleteSite(site) },
                onDeleteAccount = { site, account -> confirmDeleteAccount(site, account) }
            )
        }
        refreshEmptyState()
    }

    private fun refreshEmptyState() {
        val isEmpty = storage.getSites().isEmpty()
        binding.emptyStateText.visibility = if (isEmpty) android.view.View.VISIBLE else android.view.View.GONE
        binding.sitesRecyclerView.visibility = if (isEmpty) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun refreshRecent() {
        val recent = storage.getRecent()
        if (recent == null) {
            binding.recentLabel.visibility = android.view.View.GONE
            binding.recentCard.visibility = android.view.View.GONE
            return
        }
        val (site, account) = recent
        binding.recentLabel.visibility = android.view.View.VISIBLE
        binding.recentCard.visibility = android.view.View.VISIBLE
        binding.recentSiteText.text = "${site.name} — ${account.label}"
        binding.recentOpenButton.setOnClickListener { openAccount(site, account) }
    }

    private fun openAccount(site: Site, account: Account) {
        val intent = Intent(this, WebViewActivity::class.java)
        intent.putExtra("site_id", site.id)
        intent.putExtra("site_name", site.name)
        intent.putExtra("site_url", site.url)
        intent.putExtra("account_id", account.id)
        intent.putExtra("account_label", account.label)
        startActivity(intent)
    }

    private fun showAddSiteDialog() {
        val dialogBinding = DialogAddSiteBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle("Add Site")
            .setView(dialogBinding.root)
            .setPositiveButton("Add") { _, _ ->
                val name = dialogBinding.siteNameInput.text.toString().trim()
                var url = dialogBinding.siteUrlInput.text.toString().trim()
                if (name.isEmpty() || url.isEmpty()) return@setPositiveButton
                if (!url.startsWith("http")) url = "https://$url"
                storage.addSite(name, url)
                reloadSites()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddAccountDialog(site: Site) {
        val dialogBinding = DialogAddAccountBinding.inflate(layoutInflater)
        AlertDialog.Builder(this)
            .setTitle("Add Account — ${site.name}")
            .setView(dialogBinding.root)
            .setPositiveButton("Continue") { _, _ ->
                val label = dialogBinding.accountLabelInput.text.toString().trim()
                if (label.isEmpty()) return@setPositiveButton
                val account = storage.addAccount(site.id, label)
                reloadSites()
                if (account != null) {
                    openAccount(site, account) // opens fresh WebView for first-time manual login
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteSite(site: Site) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${site.name}?")
            .setMessage("This removes all its saved accounts too.")
            .setPositiveButton("Delete") { _, _ ->
                storage.deleteSite(site.id)
                reloadSites()
                refreshRecent()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDeleteAccount(site: Site, account: Account) {
        AlertDialog.Builder(this)
            .setTitle("Delete ${account.label}?")
            .setPositiveButton("Delete") { _, _ ->
                storage.deleteAccount(site.id, account.id)
                reloadSites()
                refreshRecent()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
