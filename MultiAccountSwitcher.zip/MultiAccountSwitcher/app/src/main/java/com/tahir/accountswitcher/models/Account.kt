package com.tahir.accountswitcher.models

/**
 * Represents a single logged-in identity for a Site.
 * `cookies` holds the captured session cookies (as a raw cookie header string)
 * once the user has logged in inside the WebView and tapped "Save Session".
 * Empty cookies means the account has been added but never actually logged in yet.
 */
data class Account(
    val id: String,
    var label: String,      // e.g. "tahir@gmail.com" - shown on the button
    var cookies: String = "",
    var lastUsedAt: Long = 0L
)
