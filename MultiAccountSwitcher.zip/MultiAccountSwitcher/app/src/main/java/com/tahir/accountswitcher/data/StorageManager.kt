package com.tahir.accountswitcher.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tahir.accountswitcher.models.Account
import com.tahir.accountswitcher.models.Site
import java.util.UUID

/**
 * Persists all Sites + their Accounts (including saved session cookies) to
 * encrypted on-disk storage, so credentials/sessions never sit in plain text.
 */
class StorageManager(context: Context) {

    private val gson = Gson()

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context,
        "account_switcher_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun getSites(): MutableList<Site> {
        val json = prefs.getString(KEY_SITES, null) ?: return mutableListOf()
        val type = object : TypeToken<MutableList<Site>>() {}.type
        return gson.fromJson(json, type) ?: mutableListOf()
    }

    fun saveSites(sites: List<Site>) {
        prefs.edit().putString(KEY_SITES, gson.toJson(sites)).apply()
    }

    fun addSite(name: String, url: String): Site {
        val sites = getSites()
        val site = Site(id = UUID.randomUUID().toString(), name = name, url = url)
        sites.add(site)
        saveSites(sites)
        return site
    }

    fun deleteSite(siteId: String) {
        val sites = getSites()
        sites.removeAll { it.id == siteId }
        saveSites(sites)
    }

    fun addAccount(siteId: String, label: String): Account? {
        val sites = getSites()
        val site = sites.find { it.id == siteId } ?: return null
        val account = Account(id = UUID.randomUUID().toString(), label = label)
        site.accounts.add(account)
        saveSites(sites)
        return account
    }

    fun deleteAccount(siteId: String, accountId: String) {
        val sites = getSites()
        val site = sites.find { it.id == siteId } ?: return
        site.accounts.removeAll { it.id == accountId }
        saveSites(sites)
    }

    /** Called after the user logs in inside the WebView and taps "Save Session". */
    fun updateAccountCookies(siteId: String, accountId: String, cookies: String) {
        val sites = getSites()
        val site = sites.find { it.id == siteId } ?: return
        val account = site.accounts.find { it.id == accountId } ?: return
        account.cookies = cookies
        account.lastUsedAt = System.currentTimeMillis()
        saveSites(sites)
        setRecent(siteId, accountId)
    }

    fun markUsed(siteId: String, accountId: String) {
        val sites = getSites()
        val site = sites.find { it.id == siteId } ?: return
        val account = site.accounts.find { it.id == accountId } ?: return
        account.lastUsedAt = System.currentTimeMillis()
        saveSites(sites)
        setRecent(siteId, accountId)
    }

    private fun setRecent(siteId: String, accountId: String) {
        prefs.edit()
            .putString(KEY_RECENT_SITE, siteId)
            .putString(KEY_RECENT_ACCOUNT, accountId)
            .apply()
    }

    /** Returns the most recently used (site, account) pair, or null if none yet. */
    fun getRecent(): Pair<Site, Account>? {
        val siteId = prefs.getString(KEY_RECENT_SITE, null) ?: return null
        val accountId = prefs.getString(KEY_RECENT_ACCOUNT, null) ?: return null
        val site = getSites().find { it.id == siteId } ?: return null
        val account = site.accounts.find { it.id == accountId } ?: return null
        return Pair(site, account)
    }

    companion object {
        private const val KEY_SITES = "sites_json"
        private const val KEY_RECENT_SITE = "recent_site_id"
        private const val KEY_RECENT_ACCOUNT = "recent_account_id"
    }
}
