package com.tahir.accountswitcher.data

import android.webkit.CookieManager
import android.webkit.ValueCallback

/**
 * Handles switching between saved login sessions for a single site (domain)
 * by manipulating WebView cookies directly — no real "logout" call to the
 * site is needed, we just swap which account's cookies are active.
 */
object CookieSessionManager {

    /**
     * Wipes any cookies currently set for [url], then (if [savedCookies] is
     * non-empty) injects the saved session for the account being switched to,
     * then invokes [onReady] once cookies are flushed to disk.
     */
    fun switchTo(url: String, savedCookies: String, onReady: () -> Unit) {
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        clearCookiesForUrl(url) {
            if (savedCookies.isNotBlank()) {
                injectCookies(url, savedCookies)
            }
            cookieManager.flush()
            onReady()
        }
    }

    /** Reads back whatever cookies are currently active for [url] (used by "Save Session"). */
    fun captureCookies(url: String): String {
        return CookieManager.getInstance().getCookie(url) ?: ""
    }

    private fun clearCookiesForUrl(url: String, onDone: () -> Unit) {
        val cookieManager = CookieManager.getInstance()
        val existing = cookieManager.getCookie(url)
        if (existing.isNullOrBlank()) {
            onDone()
            return
        }
        existing.split(";").forEach { pair ->
            val name = pair.substringBefore("=").trim()
            if (name.isNotEmpty()) {
                cookieManager.setCookie(url, "$name=; Max-Age=0; Path=/")
            }
        }
        cookieManager.removeSessionCookies(ValueCallback { onDone() })
    }

    private fun injectCookies(url: String, savedCookies: String) {
        val cookieManager = CookieManager.getInstance()
        savedCookies.split(";").forEach { pair ->
            val trimmed = pair.trim()
            if (trimmed.isNotEmpty()) {
                cookieManager.setCookie(url, trimmed)
            }
        }
    }
}
