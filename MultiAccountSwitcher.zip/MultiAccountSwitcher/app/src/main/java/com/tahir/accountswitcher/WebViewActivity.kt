package com.tahir.accountswitcher

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tahir.accountswitcher.data.CookieSessionManager
import com.tahir.accountswitcher.data.StorageManager
import com.tahir.accountswitcher.databinding.ActivityWebviewBinding

class WebViewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWebviewBinding
    private lateinit var storage: StorageManager

    private lateinit var siteId: String
    private lateinit var siteUrl: String
    private lateinit var accountId: String
    private lateinit var accountLabel: String

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWebviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.webToolbar)

        storage = StorageManager(this)

        siteId = intent.getStringExtra("site_id") ?: return finish()
        siteUrl = intent.getStringExtra("site_url") ?: return finish()
        accountId = intent.getStringExtra("account_id") ?: return finish()
        accountLabel = intent.getStringExtra("account_label") ?: ""
        val siteName = intent.getStringExtra("site_name") ?: ""

        supportActionBar?.title = "$siteName — $accountLabel"

        val savedCookies = findSavedCookies()
        val isFirstTimeSetup = savedCookies.isBlank()
        binding.setupBar.visibility = if (isFirstTimeSetup) android.view.View.VISIBLE else android.view.View.GONE

        setupWebView()

        // Clear whatever cookies exist for this domain, inject this account's saved
        // session (if any), then load — this is the actual "switch account" step.
        CookieSessionManager.switchTo(siteUrl, savedCookies) {
            runOnUiThread { binding.webView.loadUrl(siteUrl) }
        }

        binding.saveSessionButton.setOnClickListener {
            val cookies = CookieSessionManager.captureCookies(siteUrl)
            if (cookies.isBlank()) {
                Toast.makeText(this, "Not logged in yet — log in first, then Save.", Toast.LENGTH_SHORT).show()
            } else {
                storage.updateAccountCookies(siteId, accountId, cookies)
                binding.setupBar.visibility = android.view.View.GONE
                Toast.makeText(this, "Session saved for $accountLabel", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun findSavedCookies(): String {
        val site = storage.getSites().find { it.id == siteId } ?: return ""
        val account = site.accounts.find { it.id == accountId } ?: return ""
        return account.cookies
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView: WebView = binding.webView
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.setSupportZoom(true)
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                binding.progressBar.visibility = android.view.View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = android.view.View.GONE
                // Once the account has an active session (not first-time setup),
                // record it as the most recently used account for the "Recent" card.
                if (binding.setupBar.visibility == android.view.View.GONE) {
                    storage.markUsed(siteId, accountId)
                }
            }
        }
    }

    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
