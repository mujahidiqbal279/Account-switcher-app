package com.tahir.accountswitcher.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.tahir.accountswitcher.R
import com.tahir.accountswitcher.databinding.ItemSiteBinding
import com.tahir.accountswitcher.models.Account
import com.tahir.accountswitcher.models.Site

class SiteAdapter(
    private val sites: MutableList<Site>,
    private val onAccountClick: (Site, Account) -> Unit,
    private val onAddAccountClick: (Site) -> Unit,
    private val onDeleteSite: (Site) -> Unit,
    private val onDeleteAccount: (Site, Account) -> Unit
) : RecyclerView.Adapter<SiteAdapter.SiteViewHolder>() {

    inner class SiteViewHolder(val binding: ItemSiteBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SiteViewHolder {
        val binding = ItemSiteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SiteViewHolder(binding)
    }

    override fun getItemCount(): Int = sites.size

    override fun onBindViewHolder(holder: SiteViewHolder, position: Int) {
        val site = sites[position]
        val binding = holder.binding

        binding.siteNameText.text = site.name
        binding.accountsChipGroup.removeAllViews()

        for (account in site.accounts) {
            val chip = Chip(binding.root.context)
            chip.text = account.label
            chip.isCheckable = false
            chip.chipBackgroundColor = binding.root.context.getColorStateList(
                if (account.cookies.isNotBlank()) R.color.amber else R.color.light_gray
            )
            chip.setTextColor(
                binding.root.context.getColor(
                    if (account.cookies.isNotBlank()) R.color.white else R.color.dark_gray
                )
            )
            chip.isCloseIconVisible = true
            chip.setOnClickListener { onAccountClick(site, account) }
            chip.setOnCloseIconClickListener { onDeleteAccount(site, account) }
            binding.accountsChipGroup.addView(chip)
        }

        binding.addAccountChip.setOnClickListener { onAddAccountClick(site) }
        binding.deleteSiteButton.setOnClickListener { onDeleteSite(site) }
    }
}
